import Image from 'next/image'
export default function Navbar(){ 
  return (
    <header className="header text-white">
      <div className="container flex items-center gap-4 py-4">
        <div className="w-14 h-14 relative">
          <Image src="/logo.png" alt="TVCA Logo" fill sizes="56px" style={{objectFit:'contain'}} />
        </div>
        <div>
          <h1 className="text-xl font-bold">True Vine Christian Assembly</h1>
          <p className="text-sm">Awakening Destinies, Transforming Society — Isaiah 60:1</p>
        </div>
        <nav className="ml-auto flex gap-3">
          <a href="/" className="px-3 py-1">Home</a>
          <a href="/sermons" className="px-3 py-1">Sermons</a>
          <a href="/live" className="px-3 py-1">Live</a>
          <a href="/events" className="px-3 py-1">Events</a>
          <a href="/give" className="px-3 py-1">Give</a>
          <a href="/contact" className="px-3 py-1">Contact</a>
          <a href="/admin" className="px-3 py-1">Admin</a>
        </nav>
      </div>
    </header>
  )
}
