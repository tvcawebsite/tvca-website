export default function VideoEmbed({url, title}){
  return (
    <div className="w-full aspect-video">
      <iframe className="w-full h-full" src={url} title={title} allowFullScreen></iframe>
    </div>
  )
}
