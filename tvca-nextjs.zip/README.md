# TVCA Next.js 13 Website

Next.js 13 (pages router) + Tailwind + Framer Motion.

## Quick start

1. Install
```
npm install
```

2. Local env
Create `.env.local`:
```
NEXT_PUBLIC_ADMIN_PASS=MYWEB
```

3. Run local
```
npm run dev
```

## Deploy to Vercel
- Import repository or upload zip
- Set environment variables in Vercel: NEXT_PUBLIC_ADMIN_PASS
