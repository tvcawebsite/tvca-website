export default function Live(){
  return (
    <div>
      <h2 className="text-3xl font-bold text-primary">Live Service</h2>
      <p className="mt-2 text-gray-700">Join our live service on any of these platforms.</p>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-semibold">YouTube</h3>
          <iframe className="w-full aspect-video" src="https://www.youtube.com/embed/" title="YouTube Live" allowFullScreen></iframe>
        </div>
        <div>
          <h3 className="font-semibold">Facebook</h3>
          <iframe className="w-full aspect-video" src="https://www.facebook.com/plugins/video.php?href=" title="Facebook Live" allowFullScreen></iframe>
        </div>
      </div>
    </div>
  )
}
