import VideoEmbed from '../components/VideoEmbed'
export default function Sermons(){
  const sermons = [
    {id:1, title:'Arise and Shine', url:'https://www.youtube.com/embed/VIDEO_ID_1'},
    {id:2, title:'Walking in Purpose', url:'https://www.youtube.com/embed/VIDEO_ID_2'}
  ]
  return (
    <div>
      <h2 className="text-3xl font-bold text-primary">Sermons & Messages</h2>
      <p className="text-gray-700 mt-2">Watch or listen to previous messages.</p>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        {sermons.map(s=>(
          <div key={s.id} className="border rounded p-4">
            <h3 className="font-semibold">{s.title}</h3>
            <div className="mt-3"><VideoEmbed url={s.url} title={s.title} /></div>
          </div>
        ))}
      </div>
    </div>
  )
}
