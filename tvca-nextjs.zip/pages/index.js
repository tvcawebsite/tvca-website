import { motion } from 'framer-motion'
export default function Home(){
  return (
    <div>
      <section className="text-center py-16 rounded-xl bg-gradient-to-b from-green-700 to-green-800 text-white">
        <motion.h2 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="text-4xl font-bold">True Vine Christian Assembly</motion.h2>
        <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.3}} className="mt-4 text-xl text-yellow-300">Awakening Destinies, Transforming Society — Isaiah 60:1</motion.p>
        <div className="mt-8"><a href="/live" className="inline-block bg-yellow-400 text-green-900 px-6 py-3 rounded-lg font-semibold">Join Live Service</a></div>
      </section>

      <section className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="p-6 border rounded">
          <h3 className="font-bold text-lg">Latest Sermon</h3>
          <p className="mt-2 text-sm text-gray-600">Watch the most recent message from Apostle Francis.</p>
        </div>
        <div className="p-6 border rounded">
          <h3 className="font-bold text-lg">Upcoming Event</h3>
          <p className="mt-2 text-sm text-gray-600">Monthly Outreach — details and RSVP.</p>
        </div>
        <div className="p-6 border rounded">
          <h3 className="font-bold text-lg">Give</h3>
          <p className="mt-2 text-sm text-gray-600">Support the ministry via Paystack or Flutterwave.</p>
        </div>
      </section>
    </div>
  )
}
