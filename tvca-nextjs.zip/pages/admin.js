import { useState } from 'react'
export default function Admin(){
  const [logged, setLogged] = useState(false)
  const [pass, setPass] = useState('')
  const [site, setSite] = useState({title:'True Vine Christian Assembly', address:'No. 4, Banyan Street, Woodhill Estate Phase II, Kuje, Abuja', services:'Sundays, Wednesdays, Fridays'})

  const login = ()=>{
    if(pass === process.env.NEXT_PUBLIC_ADMIN_PASS) setLogged(true)
    else alert('Incorrect password')
  }
  const save = async ()=>{
    const res = await fetch('/api/site', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(site)})
    if(res.ok) alert('Saved')
    else alert('Save failed')
  }

  if(!logged) return (
    <div className='min-h-screen flex items-center justify-center p-8'>
      <div className='max-w-md w-full border p-6 rounded'>
        <h2 className='text-xl font-bold mb-4'>Admin Login</h2>
        <input type='password' value={pass} onChange={e=>setPass(e.target.value)} placeholder='password' className='w-full border p-2 rounded mb-4' />
        <button onClick={login} className='w-full bg-primary text-white p-2 rounded'>Login</button>
      </div>
    </div>
  )

  return (
    <div>
      <h2 className='text-2xl font-bold'>Admin Panel</h2>
      <div className='mt-4 grid md:grid-cols-2 gap-4'>
        <div>
          <label className='block text-sm font-medium'>Church Title</label>
          <input value={site.title} onChange={e=>setSite({...site,title:e.target.value})} className='w-full border p-2 rounded' />
        </div>
        <div>
          <label className='block text-sm font-medium'>Address</label>
          <input value={site.address} onChange={e=>setSite({...site,address:e.target.value})} className='w-full border p-2 rounded' />
        </div>
      </div>
      <div className='mt-4'>
        <label className='block text-sm font-medium'>Service Times</label>
        <input value={site.services} onChange={e=>setSite({...site,services:e.target.value})} className='w-full border p-2 rounded' />
      </div>
      <div className='mt-4 flex gap-3'><button onClick={save} className='bg-accent text-green-900 px-4 py-2 rounded'>Save</button></div>
    </div>
  )
}
