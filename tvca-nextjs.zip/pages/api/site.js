import fs from 'fs';
import path from 'path';

export default function handler(req, res){
  const file = path.join(process.cwd(), 'data', 'site.json');
  if(req.method === 'GET'){
    if(fs.existsSync(file)){
      const raw = fs.readFileSync(file,'utf-8');
      res.status(200).json(JSON.parse(raw));
    } else {
      res.status(200).json({title:'True Vine Christian Assembly', address:'No. 4, Banyan Street, Woodhill Estate Phase II, Kuje, Abuja', services:'Sundays, Wednesdays, Fridays'});
    }
  } else if(req.method === 'POST'){
    try{
      fs.mkdirSync(path.dirname(file), {recursive: true});
      fs.writeFileSync(file, JSON.stringify(req.body, null, 2));
      res.status(200).json({ok:true});
    }catch(e){
      res.status(500).json({ok:false, error: String(e)});
    }
  } else {
    res.status(405).end();
  }
}
