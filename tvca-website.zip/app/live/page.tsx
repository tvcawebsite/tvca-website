export default function LiveService() {
  return (
    <div className='min-h-screen bg-white text-center py-10'>
      <h1 className='text-3xl font-bold text-primary mb-6'>Live Service</h1>
      <p className='text-gray-700 mb-8'>Connect with us on any of our streaming platforms.</p>
      <div className='flex flex-wrap justify-center gap-6'>
        <iframe width='360' height='215' src='https://www.youtube.com/embed/' title='YouTube Live' allowFullScreen></iframe>
      </div>
    </div>
  );
}