import "./globals.css";
export const metadata = {
  title: "True Vine Christian Assembly — Awakening Destinies, Transforming Society",
  description: "Awakening Destinies, Transforming Society — Isaiah 60:1"
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang='en'>
      <body>{children}</body>
    </html>
  );
}