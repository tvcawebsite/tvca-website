'use client';
import { useState } from 'react';
export default function Admin() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const handleLogin = () => {
    if (password === process.env.NEXT_PUBLIC_ADMIN_PASS) setLoggedIn(true);
    else alert('Incorrect password');
  };
  if (!loggedIn)
    return (
      <div className='min-h-screen flex flex-col items-center justify-center'>
        <h1 className='text-3xl font-bold mb-4'>Admin Login</h1>
        <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} placeholder='Enter password' className='border p-2 rounded mb-4' />
        <button onClick={handleLogin} className='bg-primary text-white px-4 py-2 rounded'>Login</button>
      </div>
    );
  return (
    <div className='p-6'>
      <h1 className='text-2xl font-bold mb-4'>Admin Panel</h1>
      <p>Here you’ll add editing forms for address, logo upload, links, etc.</p>
    </div>
  );
}