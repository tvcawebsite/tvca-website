'use client';
import { motion } from 'framer-motion';
export default function Home() {
  return (
    <main className='min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-primary to-secondary text-white text-center px-6'>
      <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className='text-4xl md:text-6xl font-bold mb-4'>
        True Vine Christian Assembly
      </motion.h1>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className='text-xl md:text-2xl text-accent font-semibold'>
        Awakening Destinies, Transforming Society — Isaiah 60:1
      </motion.p>
      <motion.a href='/live' className='mt-10 px-6 py-3 bg-accent text-primary font-semibold rounded-xl shadow-lg hover:bg-yellow-400' whileHover={{ scale: 1.05 }}>
        Join Live Service
      </motion.a>
    </main>
  );
}