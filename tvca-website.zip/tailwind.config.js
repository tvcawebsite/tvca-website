module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#5B2C6F",
        accent: "#FFD700",
        secondary: "#1B1F3B"
      }
    }
  },
  plugins: []
};